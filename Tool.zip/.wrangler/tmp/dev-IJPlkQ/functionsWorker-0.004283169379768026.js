var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// .wrangler/tmp/pages-MQjEzN/functionsWorker-0.004283169379768026.mjs
var __defProp2 = Object.defineProperty;
var __name2 = /* @__PURE__ */ __name((target, value) => __defProp2(target, "name", { value, configurable: true }), "__name");
var TOTAL_SLOTS = 16;
var MILESTONES = [8, 16];
var ATTEMPT_WINDOW_MS = 10 * 60 * 1e3;
var MAX_FAILS_PER_CARD = 8;
var MAX_FAILS_PER_IP = 40;
var CODE_RE = /^\d{7}$/;
async function onRequest(ctx) {
  const { request, env } = ctx;
  const method = request.method.toUpperCase();
  const url = new URL(request.url);
  const raw = ctx.params ? ctx.params.path : [];
  const seg = Array.isArray(raw) ? raw : raw ? [raw] : [];
  try {
    if (seg[0] === "card") {
      if (seg.length === 1 && method === "POST") return createCard(request, env);
      if (seg.length === 2 && method === "GET") return readCard(env, seg[1]);
      if (seg.length === 2 && method === "PATCH") return savePhone(request, env, seg[1]);
      if (seg.length === 3 && seg[2] === "reset" && method === "POST") return resetCard(env, seg[1]);
      if (seg.length === 3 && seg[2] === "redeem" && method === "POST") return redeemReward(request, env, seg[1]);
    }
    if (seg[0] === "stamp" && seg.length === 1 && method === "POST") return stampSlot(request, env);
    if (seg[0] === "admin") {
      const denied = requireAdmin(request, env);
      if (denied) return denied;
      if (seg[1] === "stats" && method === "GET") return adminStats(env);
      if (seg[1] === "batches" && seg.length === 2 && method === "GET") return listBatches(env);
      if (seg[1] === "batches" && seg.length === 2 && method === "POST") return createBatch(request, env);
      if (seg[1] === "batches" && seg.length === 4 && seg[3] === "codes" && method === "GET") {
        return listCodes(env, seg[2], url);
      }
      if (seg[1] === "cards" && method === "GET") return findCards(env, url);
    }
    return json({ error: "Not found." }, 404);
  } catch (err) {
    console.error("api error", err);
    return json({ error: "Something went wrong.", detail: String(err && err.message || err) }, 500);
  }
}
__name(onRequest, "onRequest");
__name2(onRequest, "onRequest");
async function createCard(request, env) {
  const body = await readJson(request);
  const phone = body.phone ? cleanPhone(body.phone) : null;
  const id = randHex(16);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  await env.DB.prepare(
    "INSERT INTO cards (id, phone, created_at, last_seen_at, cycle) VALUES (?, ?, ?, ?, 1)"
  ).bind(id, phone, now, now).run();
  return json(await cardState(env, id), 201);
}
__name(createCard, "createCard");
__name2(createCard, "createCard");
async function readCard(env, id) {
  const state = await cardState(env, id);
  if (!state) return json({ error: "Card not found." }, 404);
  await env.DB.prepare("UPDATE cards SET last_seen_at = ? WHERE id = ?").bind((/* @__PURE__ */ new Date()).toISOString(), id).run();
  return json(state);
}
__name(readCard, "readCard");
__name2(readCard, "readCard");
async function savePhone(request, env, id) {
  const body = await readJson(request);
  const card = await getCard(env, id);
  if (!card) return json({ error: "Card not found." }, 404);
  const raw = typeof body.phone === "string" ? body.phone.trim() : "";
  const phone = raw === "" ? null : cleanPhone(raw);
  if (raw !== "" && !phone) return json({ error: "Enter a valid phone number." }, 400);
  await env.DB.prepare("UPDATE cards SET phone = ?, last_seen_at = ? WHERE id = ?").bind(phone, (/* @__PURE__ */ new Date()).toISOString(), id).run();
  return json(await cardState(env, id));
}
__name(savePhone, "savePhone");
__name2(savePhone, "savePhone");
async function resetCard(env, id) {
  const card = await getCard(env, id);
  if (!card) return json({ error: "Card not found." }, 404);
  const row = await env.DB.prepare(
    "SELECT COUNT(*) AS n FROM stamps WHERE card_id = ? AND cycle = ?"
  ).bind(id, card.cycle).first();
  if (Number(row.n) < TOTAL_SLOTS) {
    return json({ error: "The card is not complete yet." }, 409);
  }
  await env.DB.prepare("UPDATE cards SET cycle = cycle + 1, last_seen_at = ? WHERE id = ?").bind((/* @__PURE__ */ new Date()).toISOString(), id).run();
  return json(await cardState(env, id));
}
__name(resetCard, "resetCard");
__name2(resetCard, "resetCard");
async function redeemReward(request, env, id) {
  const body = await readJson(request);
  const milestone = Number(body.milestone);
  if (!MILESTONES.includes(milestone)) return json({ error: "Unknown reward." }, 400);
  const card = await getCard(env, id);
  if (!card) return json({ error: "Card not found." }, 404);
  const stamped = await env.DB.prepare(
    "SELECT 1 AS ok FROM stamps WHERE card_id = ? AND cycle = ? AND slot = ?"
  ).bind(id, card.cycle, milestone).first();
  if (!stamped) return json({ error: "That reward is not unlocked yet." }, 409);
  await env.DB.prepare(
    "INSERT OR IGNORE INTO redemptions (card_id, cycle, milestone, claimed_at) VALUES (?, ?, ?, ?)"
  ).bind(id, card.cycle, milestone, (/* @__PURE__ */ new Date()).toISOString()).run();
  return json(await cardState(env, id));
}
__name(redeemReward, "redeemReward");
__name2(redeemReward, "redeemReward");
async function stampSlot(request, env) {
  const body = await readJson(request);
  const cardId = String(body.cardId || "");
  const slot = Number(body.slot);
  const code = String(body.code || "").trim();
  const ip = request.headers.get("CF-Connecting-IP") || "";
  if (!cardId) return json({ error: "Missing card." }, 400);
  if (!Number.isInteger(slot) || slot < 1 || slot > TOTAL_SLOTS) return json({ error: "Invalid slot." }, 400);
  if (!CODE_RE.test(code)) return json({ error: "Enter the 7-digit code." }, 400);
  const since = new Date(Date.now() - ATTEMPT_WINDOW_MS).toISOString();
  const cardFails = await env.DB.prepare(
    "SELECT COUNT(*) AS n FROM attempts WHERE card_id = ? AND ok = 0 AND at >= ?"
  ).bind(cardId, since).first();
  if (Number(cardFails.n) >= MAX_FAILS_PER_CARD) return tooManyAttempts();
  if (ip) {
    const ipFails = await env.DB.prepare(
      "SELECT COUNT(*) AS n FROM attempts WHERE ip = ? AND ok = 0 AND at >= ?"
    ).bind(ip, since).first();
    if (Number(ipFails.n) >= MAX_FAILS_PER_IP) return tooManyAttempts();
  }
  const state = await cardState(env, cardId);
  if (!state) return json({ error: "Card not found." }, 404);
  const filled = state.stamps.length;
  if (slot <= filled) return json({ error: "That slot is already stamped.", card: state }, 409);
  if (slot !== filled + 1) {
    return json({ error: `Stamp slot ${filled + 1} first.`, card: state }, 409);
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const burn = await env.DB.prepare(
    `UPDATE codes
        SET used_at = ?, used_by_card = ?, used_by_slot = ?
      WHERE code = ?
        AND used_at IS NULL
        AND batch_id IN (SELECT id FROM batches WHERE expires_at > ?)`
  ).bind(now, cardId, slot, code, now).run();
  const changed = burn.meta ? Number(burn.meta.changes || 0) : 0;
  if (!changed) {
    await recordAttempt(env, cardId, ip, false);
    return json({ error: "That code isn't valid or has already been used." }, 400);
  }
  try {
    await env.DB.prepare(
      "INSERT INTO stamps (card_id, cycle, slot, code, stamped_at) VALUES (?, ?, ?, ?, ?)"
    ).bind(cardId, state.cycle, slot, code, now).run();
  } catch (err) {
    await env.DB.prepare(
      "UPDATE codes SET used_at = NULL, used_by_card = NULL, used_by_slot = NULL WHERE code = ?"
    ).bind(code).run();
    return json({ error: "That slot was just stamped. Please refresh.", card: await cardState(env, cardId) }, 409);
  }
  return json(await cardState(env, cardId));
}
__name(stampSlot, "stampSlot");
__name2(stampSlot, "stampSlot");
async function recordAttempt(env, cardId, ip, ok) {
  const now = (/* @__PURE__ */ new Date()).toISOString();
  await env.DB.prepare("INSERT INTO attempts (card_id, ip, ok, at) VALUES (?, ?, ?, ?)").bind(cardId, ip || null, ok ? 1 : 0, now).run();
  await env.DB.prepare("DELETE FROM attempts WHERE at < ?").bind(new Date(Date.now() - 24 * 60 * 60 * 1e3).toISOString()).run();
}
__name(recordAttempt, "recordAttempt");
__name2(recordAttempt, "recordAttempt");
function tooManyAttempts() {
  return json({ error: "Too many wrong codes. Please wait a few minutes and try again." }, 429);
}
__name(tooManyAttempts, "tooManyAttempts");
__name2(tooManyAttempts, "tooManyAttempts");
async function adminStats(env) {
  const row = await env.DB.prepare(
    `SELECT
       (SELECT COUNT(*) FROM codes) AS codes_total,
       (SELECT COUNT(*) FROM codes WHERE used_at IS NULL) AS codes_unused,
       (SELECT COUNT(*) FROM codes WHERE used_at IS NOT NULL) AS codes_used,
       (SELECT COUNT(*) FROM cards) AS cards_total,
       (SELECT COUNT(*) FROM stamps) AS stamps_total,
       (SELECT COUNT(*) FROM redemptions) AS rewards_total`
  ).first();
  const week = await env.DB.prepare("SELECT COUNT(*) AS n FROM stamps WHERE stamped_at >= ?").bind(new Date(Date.now() - 7 * 864e5).toISOString()).first();
  return json({ ...row, stamps_week: week.n });
}
__name(adminStats, "adminStats");
__name2(adminStats, "adminStats");
async function listBatches(env) {
  const rows = await env.DB.prepare(
    `SELECT b.id, b.label, b.created_at, b.expires_at,
            COUNT(c.code) AS total,
            COALESCE(SUM(CASE WHEN c.used_at IS NOT NULL THEN 1 ELSE 0 END), 0) AS used
       FROM batches b
       LEFT JOIN codes c ON c.batch_id = b.id
      GROUP BY b.id
      ORDER BY b.created_at DESC`
  ).all();
  return json({ batches: rows.results || [] });
}
__name(listBatches, "listBatches");
__name2(listBatches, "listBatches");
async function createBatch(request, env) {
  const body = await readJson(request);
  const count = clampInt(body.count, 1, 2e3, 500);
  const days = clampInt(body.days, 1, 3650, 90);
  const label = String(body.label || "").trim().slice(0, 60) || `Batch ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}`;
  const id = "B" + Date.now().toString(36).toUpperCase() + "-" + randHex(3).toUpperCase();
  const now = /* @__PURE__ */ new Date();
  const expiresAt = new Date(now.getTime() + days * 864e5).toISOString();
  await env.DB.prepare("INSERT INTO batches (id, label, created_at, expires_at) VALUES (?, ?, ?, ?)").bind(id, label, now.toISOString(), expiresAt).run();
  let inserted = 0;
  for (let round = 0; round < 6 && inserted < count; round++) {
    const need = count - inserted;
    const fresh = /* @__PURE__ */ new Set();
    while (fresh.size < need) fresh.add(randomCode());
    const codes = [...fresh];
    const stmts = [];
    for (let i = 0; i < codes.length; i += 40) {
      const chunk = codes.slice(i, i + 40);
      const values = chunk.map(() => "(?, ?)").join(", ");
      stmts.push(
        env.DB.prepare(`INSERT OR IGNORE INTO codes (code, batch_id) VALUES ${values}`).bind(
          ...chunk.flatMap((c) => [c, id])
        )
      );
    }
    if (stmts.length) await env.DB.batch(stmts);
    const row = await env.DB.prepare("SELECT COUNT(*) AS n FROM codes WHERE batch_id = ?").bind(id).first();
    inserted = Number(row.n || 0);
  }
  return json({ id, label, count: inserted, expiresAt }, 201);
}
__name(createBatch, "createBatch");
__name2(createBatch, "createBatch");
async function listCodes(env, batchId, url) {
  const status = url.searchParams.get("status") || "all";
  const q = (url.searchParams.get("q") || "").replace(/\D/g, "").slice(0, 7);
  const batch = await env.DB.prepare(
    "SELECT id, label, created_at, expires_at FROM batches WHERE id = ?"
  ).bind(batchId).first();
  if (!batch) return json({ error: "Batch not found." }, 404);
  const where = ["batch_id = ?"];
  const params = [batchId];
  if (status === "used") where.push("used_at IS NOT NULL");
  if (status === "unused") where.push("used_at IS NULL");
  if (q) {
    where.push("code LIKE ?");
    params.push(q + "%");
  }
  const rows = await env.DB.prepare(
    `SELECT code, used_at FROM codes WHERE ${where.join(" AND ")} ORDER BY code LIMIT 600`
  ).bind(...params).all();
  return json({ batch, codes: rows.results || [] });
}
__name(listCodes, "listCodes");
__name2(listCodes, "listCodes");
async function findCards(env, url) {
  const q = (url.searchParams.get("q") || "").trim().slice(0, 40);
  const like = "%" + q + "%";
  const rows = await env.DB.prepare(
    `SELECT c.id, c.phone, c.created_at, c.last_seen_at, c.cycle,
            (SELECT COUNT(*) FROM stamps s WHERE s.card_id = c.id AND s.cycle = c.cycle) AS stamps,
            (SELECT COUNT(*) FROM redemptions r WHERE r.card_id = c.id AND r.cycle = c.cycle) AS rewards
       FROM cards c
      WHERE (? = '' OR c.phone LIKE ? OR c.id LIKE ?)
      ORDER BY c.last_seen_at DESC
      LIMIT 25`
  ).bind(q, like, like).all();
  return json({ cards: rows.results || [] });
}
__name(findCards, "findCards");
__name2(findCards, "findCards");
async function cardState(env, id) {
  const card = await getCard(env, id);
  if (!card) return null;
  const stamps = await env.DB.prepare(
    "SELECT slot FROM stamps WHERE card_id = ? AND cycle = ? ORDER BY slot"
  ).bind(id, card.cycle).all();
  const redemptions = await env.DB.prepare(
    "SELECT milestone FROM redemptions WHERE card_id = ? AND cycle = ? ORDER BY milestone"
  ).bind(id, card.cycle).all();
  return {
    id: card.id,
    cycle: card.cycle,
    phone: card.phone || null,
    createdAt: card.created_at,
    total: TOTAL_SLOTS,
    milestones: MILESTONES,
    stamps: (stamps.results || []).map((r) => r.slot),
    redemptions: (redemptions.results || []).map((r) => r.milestone)
  };
}
__name(cardState, "cardState");
__name2(cardState, "cardState");
async function getCard(env, id) {
  return env.DB.prepare("SELECT * FROM cards WHERE id = ?").bind(id).first();
}
__name(getCard, "getCard");
__name2(getCard, "getCard");
function requireAdmin(request, env) {
  const expected = env.ADMIN_TOKEN || "";
  if (!expected) return json({ error: "Admin token is not configured on the server." }, 500);
  const header = request.headers.get("Authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token || !timingSafeEqual(token, expected)) return json({ error: "Unauthorized." }, 401);
  return null;
}
__name(requireAdmin, "requireAdmin");
__name2(requireAdmin, "requireAdmin");
function timingSafeEqual(a, b) {
  const ae = new TextEncoder().encode(a);
  const be = new TextEncoder().encode(b);
  if (ae.length !== be.length) return false;
  let diff = 0;
  for (let i = 0; i < ae.length; i++) diff |= ae[i] ^ be[i];
  return diff === 0;
}
__name(timingSafeEqual, "timingSafeEqual");
__name2(timingSafeEqual, "timingSafeEqual");
function cleanPhone(value) {
  const s = String(value).trim().replace(/[^\d+]/g, "");
  const digits = s.replace(/\D/g, "");
  if (digits.length < 7 || digits.length > 15) return null;
  return s.startsWith("+") ? "+" + digits : digits;
}
__name(cleanPhone, "cleanPhone");
__name2(cleanPhone, "cleanPhone");
function randomCode() {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return String(1e6 + buf[0] % 9e6);
}
__name(randomCode, "randomCode");
__name2(randomCode, "randomCode");
function randHex(bytes) {
  const buf = crypto.getRandomValues(new Uint8Array(bytes));
  return [...buf].map((b) => b.toString(16).padStart(2, "0")).join("");
}
__name(randHex, "randHex");
__name2(randHex, "randHex");
function clampInt(value, min, max, fallback) {
  const n = parseInt(value, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(n, min), max);
}
__name(clampInt, "clampInt");
__name2(clampInt, "clampInt");
async function readJson(request) {
  try {
    return await request.json();
  } catch {
    return {};
  }
}
__name(readJson, "readJson");
__name2(readJson, "readJson");
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}
__name(json, "json");
__name2(json, "json");
var routes = [
  {
    routePath: "/api/:path*",
    mountPath: "/api",
    method: "",
    middlewares: [],
    modules: [onRequest]
  }
];
function lexer(str) {
  var tokens = [];
  var i = 0;
  while (i < str.length) {
    var char = str[i];
    if (char === "*" || char === "+" || char === "?") {
      tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
      continue;
    }
    if (char === "\\") {
      tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
      continue;
    }
    if (char === "{") {
      tokens.push({ type: "OPEN", index: i, value: str[i++] });
      continue;
    }
    if (char === "}") {
      tokens.push({ type: "CLOSE", index: i, value: str[i++] });
      continue;
    }
    if (char === ":") {
      var name = "";
      var j = i + 1;
      while (j < str.length) {
        var code = str.charCodeAt(j);
        if (
          // `0-9`
          code >= 48 && code <= 57 || // `A-Z`
          code >= 65 && code <= 90 || // `a-z`
          code >= 97 && code <= 122 || // `_`
          code === 95
        ) {
          name += str[j++];
          continue;
        }
        break;
      }
      if (!name)
        throw new TypeError("Missing parameter name at ".concat(i));
      tokens.push({ type: "NAME", index: i, value: name });
      i = j;
      continue;
    }
    if (char === "(") {
      var count = 1;
      var pattern = "";
      var j = i + 1;
      if (str[j] === "?") {
        throw new TypeError('Pattern cannot start with "?" at '.concat(j));
      }
      while (j < str.length) {
        if (str[j] === "\\") {
          pattern += str[j++] + str[j++];
          continue;
        }
        if (str[j] === ")") {
          count--;
          if (count === 0) {
            j++;
            break;
          }
        } else if (str[j] === "(") {
          count++;
          if (str[j + 1] !== "?") {
            throw new TypeError("Capturing groups are not allowed at ".concat(j));
          }
        }
        pattern += str[j++];
      }
      if (count)
        throw new TypeError("Unbalanced pattern at ".concat(i));
      if (!pattern)
        throw new TypeError("Missing pattern at ".concat(i));
      tokens.push({ type: "PATTERN", index: i, value: pattern });
      i = j;
      continue;
    }
    tokens.push({ type: "CHAR", index: i, value: str[i++] });
  }
  tokens.push({ type: "END", index: i, value: "" });
  return tokens;
}
__name(lexer, "lexer");
__name2(lexer, "lexer");
function parse(str, options) {
  if (options === void 0) {
    options = {};
  }
  var tokens = lexer(str);
  var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a, _b = options.delimiter, delimiter = _b === void 0 ? "/#?" : _b;
  var result = [];
  var key = 0;
  var i = 0;
  var path = "";
  var tryConsume = /* @__PURE__ */ __name2(function(type) {
    if (i < tokens.length && tokens[i].type === type)
      return tokens[i++].value;
  }, "tryConsume");
  var mustConsume = /* @__PURE__ */ __name2(function(type) {
    var value2 = tryConsume(type);
    if (value2 !== void 0)
      return value2;
    var _a2 = tokens[i], nextType = _a2.type, index = _a2.index;
    throw new TypeError("Unexpected ".concat(nextType, " at ").concat(index, ", expected ").concat(type));
  }, "mustConsume");
  var consumeText = /* @__PURE__ */ __name2(function() {
    var result2 = "";
    var value2;
    while (value2 = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR")) {
      result2 += value2;
    }
    return result2;
  }, "consumeText");
  var isSafe = /* @__PURE__ */ __name2(function(value2) {
    for (var _i = 0, delimiter_1 = delimiter; _i < delimiter_1.length; _i++) {
      var char2 = delimiter_1[_i];
      if (value2.indexOf(char2) > -1)
        return true;
    }
    return false;
  }, "isSafe");
  var safePattern = /* @__PURE__ */ __name2(function(prefix2) {
    var prev = result[result.length - 1];
    var prevText = prefix2 || (prev && typeof prev === "string" ? prev : "");
    if (prev && !prevText) {
      throw new TypeError('Must have text between two parameters, missing text after "'.concat(prev.name, '"'));
    }
    if (!prevText || isSafe(prevText))
      return "[^".concat(escapeString(delimiter), "]+?");
    return "(?:(?!".concat(escapeString(prevText), ")[^").concat(escapeString(delimiter), "])+?");
  }, "safePattern");
  while (i < tokens.length) {
    var char = tryConsume("CHAR");
    var name = tryConsume("NAME");
    var pattern = tryConsume("PATTERN");
    if (name || pattern) {
      var prefix = char || "";
      if (prefixes.indexOf(prefix) === -1) {
        path += prefix;
        prefix = "";
      }
      if (path) {
        result.push(path);
        path = "";
      }
      result.push({
        name: name || key++,
        prefix,
        suffix: "",
        pattern: pattern || safePattern(prefix),
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    var value = char || tryConsume("ESCAPED_CHAR");
    if (value) {
      path += value;
      continue;
    }
    if (path) {
      result.push(path);
      path = "";
    }
    var open = tryConsume("OPEN");
    if (open) {
      var prefix = consumeText();
      var name_1 = tryConsume("NAME") || "";
      var pattern_1 = tryConsume("PATTERN") || "";
      var suffix = consumeText();
      mustConsume("CLOSE");
      result.push({
        name: name_1 || (pattern_1 ? key++ : ""),
        pattern: name_1 && !pattern_1 ? safePattern(prefix) : pattern_1,
        prefix,
        suffix,
        modifier: tryConsume("MODIFIER") || ""
      });
      continue;
    }
    mustConsume("END");
  }
  return result;
}
__name(parse, "parse");
__name2(parse, "parse");
function match(str, options) {
  var keys = [];
  var re = pathToRegexp(str, keys, options);
  return regexpToFunction(re, keys, options);
}
__name(match, "match");
__name2(match, "match");
function regexpToFunction(re, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.decode, decode = _a === void 0 ? function(x) {
    return x;
  } : _a;
  return function(pathname) {
    var m = re.exec(pathname);
    if (!m)
      return false;
    var path = m[0], index = m.index;
    var params = /* @__PURE__ */ Object.create(null);
    var _loop_1 = /* @__PURE__ */ __name2(function(i2) {
      if (m[i2] === void 0)
        return "continue";
      var key = keys[i2 - 1];
      if (key.modifier === "*" || key.modifier === "+") {
        params[key.name] = m[i2].split(key.prefix + key.suffix).map(function(value) {
          return decode(value, key);
        });
      } else {
        params[key.name] = decode(m[i2], key);
      }
    }, "_loop_1");
    for (var i = 1; i < m.length; i++) {
      _loop_1(i);
    }
    return { path, index, params };
  };
}
__name(regexpToFunction, "regexpToFunction");
__name2(regexpToFunction, "regexpToFunction");
function escapeString(str) {
  return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
__name(escapeString, "escapeString");
__name2(escapeString, "escapeString");
function flags(options) {
  return options && options.sensitive ? "" : "i";
}
__name(flags, "flags");
__name2(flags, "flags");
function regexpToRegexp(path, keys) {
  if (!keys)
    return path;
  var groupsRegex = /\((?:\?<(.*?)>)?(?!\?)/g;
  var index = 0;
  var execResult = groupsRegex.exec(path.source);
  while (execResult) {
    keys.push({
      // Use parenthesized substring match if available, index otherwise
      name: execResult[1] || index++,
      prefix: "",
      suffix: "",
      modifier: "",
      pattern: ""
    });
    execResult = groupsRegex.exec(path.source);
  }
  return path;
}
__name(regexpToRegexp, "regexpToRegexp");
__name2(regexpToRegexp, "regexpToRegexp");
function arrayToRegexp(paths, keys, options) {
  var parts = paths.map(function(path) {
    return pathToRegexp(path, keys, options).source;
  });
  return new RegExp("(?:".concat(parts.join("|"), ")"), flags(options));
}
__name(arrayToRegexp, "arrayToRegexp");
__name2(arrayToRegexp, "arrayToRegexp");
function stringToRegexp(path, keys, options) {
  return tokensToRegexp(parse(path, options), keys, options);
}
__name(stringToRegexp, "stringToRegexp");
__name2(stringToRegexp, "stringToRegexp");
function tokensToRegexp(tokens, keys, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function(x) {
    return x;
  } : _d, _e = options.delimiter, delimiter = _e === void 0 ? "/#?" : _e, _f = options.endsWith, endsWith = _f === void 0 ? "" : _f;
  var endsWithRe = "[".concat(escapeString(endsWith), "]|$");
  var delimiterRe = "[".concat(escapeString(delimiter), "]");
  var route = start ? "^" : "";
  for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
    var token = tokens_1[_i];
    if (typeof token === "string") {
      route += escapeString(encode(token));
    } else {
      var prefix = escapeString(encode(token.prefix));
      var suffix = escapeString(encode(token.suffix));
      if (token.pattern) {
        if (keys)
          keys.push(token);
        if (prefix || suffix) {
          if (token.modifier === "+" || token.modifier === "*") {
            var mod = token.modifier === "*" ? "?" : "";
            route += "(?:".concat(prefix, "((?:").concat(token.pattern, ")(?:").concat(suffix).concat(prefix, "(?:").concat(token.pattern, "))*)").concat(suffix, ")").concat(mod);
          } else {
            route += "(?:".concat(prefix, "(").concat(token.pattern, ")").concat(suffix, ")").concat(token.modifier);
          }
        } else {
          if (token.modifier === "+" || token.modifier === "*") {
            throw new TypeError('Can not repeat "'.concat(token.name, '" without a prefix and suffix'));
          }
          route += "(".concat(token.pattern, ")").concat(token.modifier);
        }
      } else {
        route += "(?:".concat(prefix).concat(suffix, ")").concat(token.modifier);
      }
    }
  }
  if (end) {
    if (!strict)
      route += "".concat(delimiterRe, "?");
    route += !options.endsWith ? "$" : "(?=".concat(endsWithRe, ")");
  } else {
    var endToken = tokens[tokens.length - 1];
    var isEndDelimited = typeof endToken === "string" ? delimiterRe.indexOf(endToken[endToken.length - 1]) > -1 : endToken === void 0;
    if (!strict) {
      route += "(?:".concat(delimiterRe, "(?=").concat(endsWithRe, "))?");
    }
    if (!isEndDelimited) {
      route += "(?=".concat(delimiterRe, "|").concat(endsWithRe, ")");
    }
  }
  return new RegExp(route, flags(options));
}
__name(tokensToRegexp, "tokensToRegexp");
__name2(tokensToRegexp, "tokensToRegexp");
function pathToRegexp(path, keys, options) {
  if (path instanceof RegExp)
    return regexpToRegexp(path, keys);
  if (Array.isArray(path))
    return arrayToRegexp(path, keys, options);
  return stringToRegexp(path, keys, options);
}
__name(pathToRegexp, "pathToRegexp");
__name2(pathToRegexp, "pathToRegexp");
var escapeRegex = /[.+?^${}()|[\]\\]/g;
function* executeRequest(request) {
  const requestPath = new URL(request.url).pathname;
  for (const route of [...routes].reverse()) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult) {
      for (const handler of route.middlewares.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: mountMatchResult.path
        };
      }
    }
  }
  for (const route of routes) {
    if (route.method && route.method !== request.method) {
      continue;
    }
    const routeMatcher = match(route.routePath.replace(escapeRegex, "\\$&"), {
      end: true
    });
    const mountMatcher = match(route.mountPath.replace(escapeRegex, "\\$&"), {
      end: false
    });
    const matchResult = routeMatcher(requestPath);
    const mountMatchResult = mountMatcher(requestPath);
    if (matchResult && mountMatchResult && route.modules.length) {
      for (const handler of route.modules.flat()) {
        yield {
          handler,
          params: matchResult.params,
          path: matchResult.path
        };
      }
      break;
    }
  }
}
__name(executeRequest, "executeRequest");
__name2(executeRequest, "executeRequest");
var pages_template_worker_default = {
  async fetch(originalRequest, env, workerContext) {
    let request = originalRequest;
    const handlerIterator = executeRequest(request);
    let data = {};
    let isFailOpen = false;
    const next = /* @__PURE__ */ __name2(async (input, init) => {
      if (input !== void 0) {
        let url = input;
        if (typeof input === "string") {
          url = new URL(input, request.url).toString();
        }
        request = new Request(url, init);
      }
      const result = handlerIterator.next();
      if (result.done === false) {
        const { handler, params, path } = result.value;
        const context = {
          request: new Request(request.clone()),
          functionPath: path,
          next,
          params,
          get data() {
            return data;
          },
          set data(value) {
            if (typeof value !== "object" || value === null) {
              throw new Error("context.data must be an object");
            }
            data = value;
          },
          env,
          waitUntil: workerContext.waitUntil.bind(workerContext),
          passThroughOnException: /* @__PURE__ */ __name2(() => {
            isFailOpen = true;
          }, "passThroughOnException")
        };
        const response = await handler(context);
        if (!(response instanceof Response)) {
          throw new Error("Your Pages function should return a Response");
        }
        return cloneResponse(response);
      } else if ("ASSETS") {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      } else {
        const response = await fetch(request);
        return cloneResponse(response);
      }
    }, "next");
    try {
      return await next();
    } catch (error) {
      if (isFailOpen) {
        const response = await env["ASSETS"].fetch(request);
        return cloneResponse(response);
      }
      throw error;
    }
  }
};
var cloneResponse = /* @__PURE__ */ __name2((response) => (
  // https://fetch.spec.whatwg.org/#null-body-status
  new Response(
    [101, 204, 205, 304].includes(response.status) ? null : response.body,
    response
  )
), "cloneResponse");
var drainBody = /* @__PURE__ */ __name2(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default = drainBody;
function reduceError(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError(e.cause)
  };
}
__name(reduceError, "reduceError");
__name2(reduceError, "reduceError");
var jsonError = /* @__PURE__ */ __name2(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError(e);
    const body = JSON.stringify(error);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default = jsonError;
var __INTERNAL_WRANGLER_MIDDLEWARE__ = [
  middleware_ensure_req_body_drained_default,
  middleware_miniflare3_json_error_default
];
var middleware_insertion_facade_default = pages_template_worker_default;
var __facade_middleware__ = [];
function __facade_register__(...args) {
  __facade_middleware__.push(...args.flat());
}
__name(__facade_register__, "__facade_register__");
__name2(__facade_register__, "__facade_register__");
function __facade_invokeChain__(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__, "__facade_invokeChain__");
__name2(__facade_invokeChain__, "__facade_invokeChain__");
function __facade_invoke__(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__(request, env, ctx, dispatch, [
    ...__facade_middleware__,
    finalMiddleware
  ]);
}
__name(__facade_invoke__, "__facade_invoke__");
__name2(__facade_invoke__, "__facade_invoke__");
var __Facade_ScheduledController__ = class ___Facade_ScheduledController__ {
  static {
    __name(this, "___Facade_ScheduledController__");
  }
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name2(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name2(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name2(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler, "wrapExportedHandler");
__name2(wrapExportedHandler, "wrapExportedHandler");
function wrapWorkerEntrypoint(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__ === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__) {
    __facade_register__(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name2((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name2((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
__name2(wrapWorkerEntrypoint, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY;
if (typeof middleware_insertion_facade_default === "object") {
  WRAPPED_ENTRY = wrapExportedHandler(middleware_insertion_facade_default);
} else if (typeof middleware_insertion_facade_default === "function") {
  WRAPPED_ENTRY = wrapWorkerEntrypoint(middleware_insertion_facade_default);
}
var middleware_loader_entry_default = WRAPPED_ENTRY;

// node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts
var drainBody2 = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } finally {
    try {
      if (request.body !== null && !request.bodyUsed) {
        const reader = request.body.getReader();
        while (!(await reader.read()).done) {
        }
      }
    } catch (e) {
      console.error("Failed to drain the unused request body.", e);
    }
  }
}, "drainBody");
var middleware_ensure_req_body_drained_default2 = drainBody2;

// node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts
function reduceError2(e) {
  return {
    name: e?.name,
    message: e?.message ?? String(e),
    stack: e?.stack,
    cause: e?.cause === void 0 ? void 0 : reduceError2(e.cause)
  };
}
__name(reduceError2, "reduceError");
var jsonError2 = /* @__PURE__ */ __name(async (request, env, _ctx, middlewareCtx) => {
  try {
    return await middlewareCtx.next(request, env);
  } catch (e) {
    const error = reduceError2(e);
    const body = JSON.stringify(error);
    const headers = {
      "Content-Type": "application/json",
      "MF-Experimental-Error-Stack": "true"
    };
    const encoded = encodeURIComponent(body);
    if (encoded.length <= 8192) {
      headers["MF-Experimental-Error-Stack-Payload"] = encoded;
    }
    return new Response(body, { status: 500, headers });
  }
}, "jsonError");
var middleware_miniflare3_json_error_default2 = jsonError2;

// .wrangler/tmp/bundle-zlLa06/middleware-insertion-facade.js
var __INTERNAL_WRANGLER_MIDDLEWARE__2 = [
  middleware_ensure_req_body_drained_default2,
  middleware_miniflare3_json_error_default2
];
var middleware_insertion_facade_default2 = middleware_loader_entry_default;

// node_modules/wrangler/templates/middleware/common.ts
var __facade_middleware__2 = [];
function __facade_register__2(...args) {
  __facade_middleware__2.push(...args.flat());
}
__name(__facade_register__2, "__facade_register__");
function __facade_invokeChain__2(request, env, ctx, dispatch, middlewareChain) {
  const [head, ...tail] = middlewareChain;
  const middlewareCtx = {
    dispatch,
    next(newRequest, newEnv) {
      return __facade_invokeChain__2(newRequest, newEnv, ctx, dispatch, tail);
    }
  };
  return head(request, env, ctx, middlewareCtx);
}
__name(__facade_invokeChain__2, "__facade_invokeChain__");
function __facade_invoke__2(request, env, ctx, dispatch, finalMiddleware) {
  return __facade_invokeChain__2(request, env, ctx, dispatch, [
    ...__facade_middleware__2,
    finalMiddleware
  ]);
}
__name(__facade_invoke__2, "__facade_invoke__");

// .wrangler/tmp/bundle-zlLa06/middleware-loader.entry.ts
var __Facade_ScheduledController__2 = class ___Facade_ScheduledController__2 {
  constructor(scheduledTime, cron, noRetry) {
    this.scheduledTime = scheduledTime;
    this.cron = cron;
    this.#noRetry = noRetry;
  }
  scheduledTime;
  cron;
  static {
    __name(this, "__Facade_ScheduledController__");
  }
  #noRetry;
  noRetry() {
    if (!(this instanceof ___Facade_ScheduledController__2)) {
      throw new TypeError("Illegal invocation");
    }
    this.#noRetry();
  }
};
function wrapExportedHandler2(worker) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return worker;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  const fetchDispatcher = /* @__PURE__ */ __name(function(request, env, ctx) {
    if (worker.fetch === void 0) {
      throw new Error("Handler does not export a fetch() function.");
    }
    return worker.fetch(request, env, ctx);
  }, "fetchDispatcher");
  return {
    ...worker,
    fetch(request, env, ctx) {
      const dispatcher = /* @__PURE__ */ __name(function(type, init) {
        if (type === "scheduled" && worker.scheduled !== void 0) {
          const controller = new __Facade_ScheduledController__2(
            Date.now(),
            init.cron ?? "",
            () => {
            }
          );
          return worker.scheduled(controller, env, ctx);
        }
      }, "dispatcher");
      return __facade_invoke__2(request, env, ctx, dispatcher, fetchDispatcher);
    }
  };
}
__name(wrapExportedHandler2, "wrapExportedHandler");
function wrapWorkerEntrypoint2(klass) {
  if (__INTERNAL_WRANGLER_MIDDLEWARE__2 === void 0 || __INTERNAL_WRANGLER_MIDDLEWARE__2.length === 0) {
    return klass;
  }
  for (const middleware of __INTERNAL_WRANGLER_MIDDLEWARE__2) {
    __facade_register__2(middleware);
  }
  return class extends klass {
    #fetchDispatcher = /* @__PURE__ */ __name((request, env, ctx) => {
      this.env = env;
      this.ctx = ctx;
      if (super.fetch === void 0) {
        throw new Error("Entrypoint class does not define a fetch() function.");
      }
      return super.fetch(request);
    }, "#fetchDispatcher");
    #dispatcher = /* @__PURE__ */ __name((type, init) => {
      if (type === "scheduled" && super.scheduled !== void 0) {
        const controller = new __Facade_ScheduledController__2(
          Date.now(),
          init.cron ?? "",
          () => {
          }
        );
        return super.scheduled(controller);
      }
    }, "#dispatcher");
    fetch(request) {
      return __facade_invoke__2(
        request,
        this.env,
        this.ctx,
        this.#dispatcher,
        this.#fetchDispatcher
      );
    }
  };
}
__name(wrapWorkerEntrypoint2, "wrapWorkerEntrypoint");
var WRAPPED_ENTRY2;
if (typeof middleware_insertion_facade_default2 === "object") {
  WRAPPED_ENTRY2 = wrapExportedHandler2(middleware_insertion_facade_default2);
} else if (typeof middleware_insertion_facade_default2 === "function") {
  WRAPPED_ENTRY2 = wrapWorkerEntrypoint2(middleware_insertion_facade_default2);
}
var middleware_loader_entry_default2 = WRAPPED_ENTRY2;
export {
  __INTERNAL_WRANGLER_MIDDLEWARE__2 as __INTERNAL_WRANGLER_MIDDLEWARE__,
  middleware_loader_entry_default2 as default
};
//# sourceMappingURL=functionsWorker-0.004283169379768026.js.map
